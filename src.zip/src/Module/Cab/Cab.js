import React from 'react'
import Component1 from './Sections/component1'
import Component2 from './Sections/component2'

const Cab = () => {
  return (
    <>
    <Component1/>
    <Component2 />
    </>
  )
}

export default Cab